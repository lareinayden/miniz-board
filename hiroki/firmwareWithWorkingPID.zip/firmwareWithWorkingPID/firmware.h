#ifndef _FIRMWARE_H_
#define _FIRMWARE_H_
extern volatile float throttle;
extern volatile float steering;
#endif
